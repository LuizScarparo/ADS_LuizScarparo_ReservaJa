import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AppRoutes from './routes/routes';

function App() {
  return (
    <AppRoutes />
  );
}

export default App;
